const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const storySchema = new Schema({
    title: { type: String, required: [true, 'title is required'] },
    author: { type: String, required: [true, 'author is required'] },
    content: {
        type: String, required: [true, 'content is required'],
        minLength: [10, 'content should be atleast 10 character']
    }

},
    { timeStamps: true }
);

module.exports = mongoose.model(Story, storySchema);

//db collection

//console.log(story);